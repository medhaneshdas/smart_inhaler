
  # AI Smart Inhaler Mobile Health App

  This is a code bundle for AI Smart Inhaler Mobile Health App. The original project is available at https://www.figma.com/design/pIFYkkx18kuBeMi0cHd6TB/AI-Smart-Inhaler-Mobile-Health-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  