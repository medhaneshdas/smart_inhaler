import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  Activity, 
  Wifi, 
  WifiOff, 
  Wind, 
  Droplets, 
  Thermometer,
  Play,
  Calendar,
  TrendingUp,
  AlertTriangle,
  Sparkles,
  Heart
} from 'lucide-react';

export function HomeScreen() {
  const techniqueAccuracy = 87;
  const isDeviceConnected = true;
  const airQuality = {
    pm25: 15,
    co: 0.8,
    humidity: 45,
    temperature: 22,
    quality: 'Good'
  };

  const todayStats = {
    sessions: 3,
    avgAccuracy: 87,
    lastSession: '2 hours ago'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-teal-50/30 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-500 to-teal-500 text-white p-8 rounded-b-[2.5rem] shadow-xl shadow-blue-500/20 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 right-8 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-8 left-4 w-24 h-24 bg-teal-300 rounded-full blur-2xl"></div>
        </div>

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-1 drop-shadow-lg">Good Morning, Sarah</h1>
              <p className="text-blue-100 drop-shadow-sm">Let's take care of your health today</p>
            </div>
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg">
              <Heart className="w-8 h-8 text-white" />
            </div>
          </div>

          {/* Device Connection Status */}
          <div className={`flex items-center gap-3 p-4 rounded-2xl backdrop-blur-sm transition-all duration-300 ${
            isDeviceConnected 
              ? 'bg-white/20 border border-white/30' 
              : 'bg-red-500/20 border border-red-300/30'
          }`}>
            {isDeviceConnected ? (
              <>
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <Wifi className="w-5 h-5" />
                <span>Smart Inhaler Connected</span>
                <Badge variant="secondary" className="ml-auto bg-green-500/20 text-green-100 border-green-300/30">
                  Active
                </Badge>
              </>
            ) : (
              <>
                <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                <WifiOff className="w-5 h-5" />
                <span>Device Disconnected</span>
                <Badge variant="destructive" className="ml-auto bg-red-500/20 text-red-100 border-red-300/30">
                  Offline
                </Badge>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Today's Technique Accuracy */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400/10 to-teal-400/10 rounded-full blur-2xl"></div>
          <CardHeader className="pb-3 relative z-10">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">
                Today's Technique Accuracy
              </CardTitle>
              <div className="p-2 bg-green-100 rounded-xl">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <CardDescription>Your inhaler technique performance</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="space-y-6">
              <div className="text-center">
                <div className="relative inline-block">
                  <div className="text-5xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent mb-2">
                    {techniqueAccuracy}%
                  </div>
                  <div className="absolute -top-1 -right-1">
                    <Sparkles className="w-6 h-6 text-yellow-500" />
                  </div>
                </div>
                <p className="text-green-600 font-medium">Excellent technique!</p>
              </div>
              
              <div className="relative">
                <Progress value={techniqueAccuracy} className="h-4 bg-green-100" />
                <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-teal-500 rounded-full" 
                     style={{ width: `${techniqueAccuracy}%` }}></div>
              </div>
              
              <div className="flex justify-between text-sm">
                <div className="text-center">
                  <div className="font-semibold text-gray-900">{todayStats.sessions}</div>
                  <div className="text-gray-600">Sessions</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-gray-900">{todayStats.avgAccuracy}%</div>
                  <div className="text-gray-600">Average</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-gray-900">{todayStats.lastSession}</div>
                  <div className="text-gray-600">Last Session</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Air Quality Monitor */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm overflow-hidden relative">
          <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-blue-400/10 to-cyan-400/10 rounded-full blur-2xl"></div>
          <CardHeader className="pb-3 relative z-10">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                Air Quality Monitor
              </CardTitle>
              <div className="p-2 bg-blue-100 rounded-xl">
                <Wind className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <CardDescription>Current environmental conditions</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-medium text-gray-900">Overall Quality</span>
                <Badge 
                  variant="secondary" 
                  className={`font-medium px-3 py-1 ${
                    airQuality.quality === 'Good' 
                      ? 'bg-green-100 text-green-800 border-green-200' 
                      : airQuality.quality === 'Moderate'
                      ? 'bg-yellow-100 text-yellow-800 border-yellow-200'
                      : 'bg-red-100 text-red-800 border-red-200'
                  }`}
                >
                  {airQuality.quality}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-4 border border-gray-100/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Wind className="w-5 h-5 text-blue-500" />
                    <span className="text-sm text-gray-600 font-medium">PM2.5</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{airQuality.pm25}</div>
                  <div className="text-xs text-gray-500">μg/m³</div>
                </div>
                
                <div className="bg-gradient-to-br from-gray-50 to-cyan-50 rounded-2xl p-4 border border-gray-100/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Droplets className="w-5 h-5 text-cyan-500" />
                    <span className="text-sm text-gray-600 font-medium">Humidity</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{airQuality.humidity}</div>
                  <div className="text-xs text-gray-500">%</div>
                </div>
                
                <div className="bg-gradient-to-br from-gray-50 to-orange-50 rounded-2xl p-4 border border-gray-100/50">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    <span className="text-sm text-gray-600 font-medium">CO</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{airQuality.co}</div>
                  <div className="text-xs text-gray-500">ppm</div>
                </div>
                
                <div className="bg-gradient-to-br from-gray-50 to-red-50 rounded-2xl p-4 border border-gray-100/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Thermometer className="w-5 h-5 text-red-500" />
                    <span className="text-sm text-gray-600 font-medium">Temperature</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{airQuality.temperature}</div>
                  <div className="text-xs text-gray-500">°C</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-gray-900">Quick Actions</h3>
          
          <Button 
            size="lg" 
            className="w-full bg-gradient-to-r from-green-600 to-teal-500 hover:from-green-700 hover:to-teal-600 h-16 rounded-2xl text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-teal-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <Play className="w-6 h-6 mr-3 relative z-10" />
            <span className="relative z-10 font-semibold">Start Inhalation Session</span>
          </Button>
          
          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="h-14 rounded-2xl border-2 border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-300 hover:scale-105">
              <Calendar className="w-5 h-5 mr-2" />
              View History
            </Button>
            
            <Button variant="outline" className="h-14 rounded-2xl border-2 border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all duration-300 hover:scale-105">
              <Activity className="w-5 h-5 mr-2" />
              Quick Stats
            </Button>
          </div>
        </div>

        {/* Health Tip */}
        <Card className="shadow-xl border-0 bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-400/20 to-teal-400/20 rounded-full blur-xl"></div>
          <CardContent className="p-6 relative z-10">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-500 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-lg font-bold text-gray-900 mb-2">Today's Health Tip</h4>
                <p className="text-gray-700 leading-relaxed">
                  Air quality is good today, but pollen levels are moderate. Consider using your inhaler 15 minutes before outdoor activities.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}