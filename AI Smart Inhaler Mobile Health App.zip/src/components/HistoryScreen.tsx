import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { 
  CheckCircle, 
  XCircle, 
  TrendingUp, 
  Calendar,
  Download,
  Share,
  Filter,
  Sparkles
} from 'lucide-react';

export function HistoryScreen() {
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  
  // Mock data for charts
  const weeklyData = [
    { day: 'Mon', accuracy: 85, sessions: 3 },
    { day: 'Tue', accuracy: 78, sessions: 2 },
    { day: 'Wed', accuracy: 92, sessions: 4 },
    { day: 'Thu', accuracy: 88, sessions: 3 },
    { day: 'Fri', accuracy: 90, sessions: 3 },
    { day: 'Sat', accuracy: 87, sessions: 2 },
    { day: 'Sun', accuracy: 91, sessions: 3 }
  ];

  const monthlyData = [
    { week: 'Week 1', accuracy: 83, sessions: 18 },
    { week: 'Week 2', accuracy: 87, sessions: 21 },
    { week: 'Week 3', accuracy: 89, sessions: 19 },
    { week: 'Week 4', accuracy: 91, sessions: 22 }
  ];

  // Mock session history data
  const recentSessions = [
    {
      id: 1,
      date: '2024-08-25',
      time: '09:30',
      duration: '5:24',
      accuracy: 92,
      breaths: 8,
      correctBreaths: 7,
      status: 'excellent'
    },
    {
      id: 2,
      date: '2024-08-25',
      time: '14:15',
      duration: '4:12',
      accuracy: 78,
      breaths: 6,
      correctBreaths: 5,
      status: 'good'
    },
    {
      id: 3,
      date: '2024-08-24',
      time: '08:45',
      duration: '6:33',
      accuracy: 95,
      breaths: 10,
      correctBreaths: 10,
      status: 'excellent'
    },
    {
      id: 4,
      date: '2024-08-24',
      time: '16:20',
      duration: '3:45',
      accuracy: 65,
      breaths: 5,
      correctBreaths: 3,
      status: 'needs-improvement'
    },
    {
      id: 5,
      date: '2024-08-23',
      time: '10:15',
      duration: '5:00',
      accuracy: 89,
      breaths: 7,
      correctBreaths: 6,
      status: 'good'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'bg-green-100 text-green-800 border-green-200';
      case 'good': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'needs-improvement': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'excellent': 
      case 'good': 
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'needs-improvement': 
        return <XCircle className="w-5 h-5 text-orange-600" />;
      default: 
        return <XCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-600 text-white p-8 rounded-b-[2.5rem] shadow-xl shadow-purple-500/20 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 right-8 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-8 left-4 w-24 h-24 bg-indigo-300 rounded-full blur-2xl"></div>
        </div>

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-1 drop-shadow-lg">History & Analytics</h1>
              <p className="text-purple-100 drop-shadow-sm">Track your progress over time</p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm">
                <Share className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button variant="outline" size="sm" className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Period Selector */}
          <div className="flex gap-2">
            {['day', 'week', 'month'].map((period) => (
              <Button
                key={period}
                variant={selectedPeriod === period ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPeriod(period)}
                className={selectedPeriod === period 
                  ? 'bg-white text-purple-600 hover:bg-white/90' 
                  : 'bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm'
                }
              >
                <span className="capitalize">{period}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Progress Charts */}
        <Tabs defaultValue="accuracy" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/80 backdrop-blur-sm rounded-2xl p-1 border-0 shadow-lg">
            <TabsTrigger value="accuracy" className="rounded-xl data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Technique Accuracy
            </TabsTrigger>
            <TabsTrigger value="sessions" className="rounded-xl data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Session Count
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="accuracy" className="space-y-4">
            <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400/10 to-teal-400/10 rounded-full blur-2xl"></div>
              <CardHeader className="relative z-10">
                <CardTitle className="flex items-center gap-3 text-xl font-bold">
                  <div className="p-2 bg-green-100 rounded-xl">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <span className="bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">
                    Accuracy Trend
                  </span>
                </CardTitle>
                <CardDescription>Your inhaler technique accuracy over time</CardDescription>
              </CardHeader>
              <CardContent className="relative z-10">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={selectedPeriod === 'month' ? monthlyData : weeklyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis 
                        dataKey={selectedPeriod === 'month' ? 'week' : 'day'} 
                        fontSize={12}
                        stroke="#6b7280"
                      />
                      <YAxis 
                        domain={[0, 100]} 
                        fontSize={12}
                        stroke="#6b7280"
                      />
                      <Tooltip 
                        formatter={(value) => [`${value}%`, 'Accuracy']}
                        labelFormatter={(label) => `${selectedPeriod === 'month' ? '' : 'Day: '}${label}`}
                        contentStyle={{
                          backgroundColor: 'rgba(255, 255, 255, 0.95)',
                          border: 'none',
                          borderRadius: '12px',
                          boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="accuracy" 
                        stroke="url(#accuracyGradient)" 
                        strokeWidth={4}
                        dot={{ fill: '#10b981', strokeWidth: 3, r: 6 }}
                        activeDot={{ r: 8, fill: '#059669' }}
                      />
                      <defs>
                        <linearGradient id="accuracyGradient" x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="#10b981" />
                          <stop offset="100%" stopColor="#14b8a6" />
                        </linearGradient>
                      </defs>
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="sessions" className="space-y-4">
            <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm overflow-hidden relative">
              <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-blue-400/10 to-indigo-400/10 rounded-full blur-2xl"></div>
              <CardHeader className="relative z-10">
                <CardTitle className="flex items-center gap-3 text-xl font-bold">
                  <div className="p-2 bg-blue-100 rounded-xl">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    Session Activity
                  </span>
                </CardTitle>
                <CardDescription>Number of inhaler sessions per day</CardDescription>
              </CardHeader>
              <CardContent className="relative z-10">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={selectedPeriod === 'month' ? monthlyData : weeklyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis 
                        dataKey={selectedPeriod === 'month' ? 'week' : 'day'} 
                        fontSize={12}
                        stroke="#6b7280"
                      />
                      <YAxis fontSize={12} stroke="#6b7280" />
                      <Tooltip 
                        formatter={(value) => [value, 'Sessions']}
                        labelFormatter={(label) => `${selectedPeriod === 'month' ? '' : 'Day: '}${label}`}
                        contentStyle={{
                          backgroundColor: 'rgba(255, 255, 255, 0.95)',
                          border: 'none',
                          borderRadius: '12px',
                          boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)'
                        }}
                      />
                      <Bar 
                        dataKey="sessions" 
                        fill="url(#sessionsGradient)" 
                        radius={[8, 8, 0, 0]}
                      />
                      <defs>
                        <linearGradient id="sessionsGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#3b82f6" />
                          <stop offset="100%" stopColor="#6366f1" />
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Session Timeline */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Recent Sessions
                </CardTitle>
                <CardDescription>Detailed log of your inhaler usage</CardDescription>
              </div>
              <Button variant="outline" size="sm" className="border-2 rounded-xl hover:scale-105 transition-transform">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSessions.map((session) => (
                <div key={session.id} className="flex items-center gap-4 p-5 border border-gray-100 rounded-2xl hover:bg-gradient-to-r hover:from-gray-50 hover:to-blue-50 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
                  <div className="flex-shrink-0 p-2 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl">
                    {getStatusIcon(session.status)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-semibold text-gray-900">
                        {session.date} at {session.time}
                      </span>
                      <Badge variant="secondary" className={`${getStatusColor(session.status)} font-medium`}>
                        {session.status.replace('-', ' ')}
                      </Badge>
                      {session.accuracy >= 90 && (
                        <Sparkles className="w-4 h-4 text-yellow-500" />
                      )}
                    </div>
                    
                    <div className="flex items-center gap-6 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <span className="font-medium">Duration:</span> {session.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="font-medium">Accuracy:</span> {session.accuracy}%
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="font-medium">Breaths:</span> {session.correctBreaths}/{session.breaths}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg ${
                      session.accuracy >= 90 ? 'bg-gradient-to-br from-green-100 to-teal-100 text-green-600' :
                      session.accuracy >= 75 ? 'bg-gradient-to-br from-blue-100 to-indigo-100 text-blue-600' :
                      'bg-gradient-to-br from-orange-100 to-red-100 text-orange-600'
                    }`}>
                      <span className="font-bold">{session.accuracy}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 text-center">
              <Button variant="outline" className="rounded-2xl border-2 hover:scale-105 transition-transform">
                Load More Sessions
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-xl border-0 bg-gradient-to-br from-green-50 to-teal-50 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-green-400/20 to-teal-400/20 rounded-full blur-xl"></div>
            <CardContent className="p-6 text-center relative z-10">
              <div className="text-4xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent mb-2">
                87%
              </div>
              <div className="font-medium text-gray-700">Avg Accuracy</div>
              <div className="text-sm text-gray-500 mt-1">This week</div>
            </CardContent>
          </Card>
          
          <Card className="shadow-xl border-0 bg-gradient-to-br from-blue-50 to-indigo-50 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-blue-400/20 to-indigo-400/20 rounded-full blur-xl"></div>
            <CardContent className="p-6 text-center relative z-10">
              <div className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
                23
              </div>
              <div className="font-medium text-gray-700">Total Sessions</div>
              <div className="text-sm text-gray-500 mt-1">This week</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}