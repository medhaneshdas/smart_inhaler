import { useState } from 'react';
import { Home, Activity, BarChart3, Brain, User, Wifi } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home, color: 'blue' },
    { id: 'session', label: 'Session', icon: Activity, color: 'green' },
    { id: 'history', label: 'History', icon: BarChart3, color: 'purple' },
    { id: 'insights', label: 'AI Insights', icon: Brain, color: 'orange' },
    { id: 'profile', label: 'Profile', icon: User, color: 'cyan' },
  ];

  const getColorClasses = (color: string, isActive: boolean) => {
    if (isActive) {
      switch (color) {
        case 'blue': return 'text-blue-600 bg-blue-50 border-blue-200';
        case 'green': return 'text-green-600 bg-green-50 border-green-200';
        case 'purple': return 'text-purple-600 bg-purple-50 border-purple-200';
        case 'orange': return 'text-orange-600 bg-orange-50 border-orange-200';
        case 'cyan': return 'text-cyan-600 bg-cyan-50 border-cyan-200';
        default: return 'text-gray-600 bg-gray-50 border-gray-200';
      }
    }
    return 'text-gray-500 hover:text-gray-700';
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-gray-200/50 px-4 py-3 safe-area-pb shadow-2xl shadow-gray-900/10">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          const colorClasses = getColorClasses(tab.color, isActive);
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center gap-1.5 px-3 py-2.5 rounded-2xl transition-all duration-300 transform hover:scale-105 ${
                isActive 
                  ? `${colorClasses} border-2 shadow-lg` 
                  : `${colorClasses} hover:bg-gray-50`
              }`}
            >
              <div className={`relative ${isActive ? 'transform scale-110' : ''}`}>
                <Icon className="w-6 h-6" />
                {isActive && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full animate-pulse"></div>
                )}
              </div>
              <span className={`text-xs font-medium ${isActive ? 'font-semibold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}