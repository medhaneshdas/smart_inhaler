import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  User, 
  Settings, 
  Bell, 
  Shield, 
  Smartphone, 
  Calendar,
  Award,
  Edit3,
  LogOut,
  ChevronRight,
  Bluetooth,
  Wifi,
  Heart,
  Target,
  Trophy,
  Sparkles
} from 'lucide-react';

export function ProfileScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [airQualityAlerts, setAirQualityAlerts] = useState(true);
  const [medicationReminders, setMedicationReminders] = useState(true);
  const [dataSharingEnabled, setDataSharingEnabled] = useState(false);

  const userStats = {
    totalSessions: 142,
    averageAccuracy: 87,
    currentStreak: 12,
    totalDays: 45
  };

  const achievements = [
    { id: 1, title: 'Perfect Week', description: '7 days of >90% accuracy', completed: true, icon: Trophy },
    { id: 2, title: 'Consistency Master', description: '30 consecutive days', completed: true, icon: Target },
    { id: 3, title: 'Technique Expert', description: '95% average accuracy', completed: false, icon: Award },
    { id: 4, title: 'Health Champion', description: '100 total sessions', completed: true, icon: Heart }
  ];

  const connectedDevices = [
    { name: 'Smart Inhaler Pro', type: 'Bluetooth', status: 'Connected', battery: 85 },
    { name: 'Air Quality Sensor', type: 'WiFi', status: 'Connected', battery: null }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-cyan-600 via-blue-600 to-indigo-600 text-white p-8 rounded-b-[2.5rem] shadow-xl shadow-cyan-500/20 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 right-8 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-8 left-4 w-24 h-24 bg-indigo-300 rounded-full blur-2xl"></div>
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center shadow-lg">
                <User className="w-10 h-10" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-1 drop-shadow-lg">Sarah Johnson</h1>
              <p className="text-cyan-100 drop-shadow-sm">sarah.johnson@email.com</p>
              <Badge className="mt-2 bg-white/20 text-white border-white/30 backdrop-blur-sm">
                Premium Member
              </Badge>
            </div>
            <Button variant="outline" size="sm" className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm">
              <Edit3 className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Sessions', value: userStats.totalSessions, color: 'text-cyan-100' },
              { label: 'Accuracy', value: `${userStats.averageAccuracy}%`, color: 'text-green-200' },
              { label: 'Streak', value: `${userStats.currentStreak} days`, color: 'text-yellow-200' },
              { label: 'Journey', value: `${userStats.totalDays} days`, color: 'text-purple-200' }
            ].map((stat, index) => (
              <div key={index} className="text-center bg-white/20 backdrop-blur-sm rounded-2xl p-3 border border-white/30">
                <div className={`text-xl font-bold ${stat.color} drop-shadow-sm`}>{stat.value}</div>
                <div className="text-xs text-white/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Achievements */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-400/10 to-orange-400/10 rounded-full blur-2xl"></div>
          <CardHeader className="relative z-10">
            <CardTitle className="flex items-center gap-3 text-xl font-bold">
              <div className="p-2 bg-yellow-100 rounded-xl">
                <Trophy className="w-6 h-6 text-yellow-600" />
              </div>
              <span className="bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
                Achievements
              </span>
            </CardTitle>
            <CardDescription>Your health milestones and accomplishments</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement) => {
                const Icon = achievement.icon;
                return (
                  <div
                    key={achievement.id}
                    className={`p-4 rounded-2xl border-2 transition-all duration-300 hover:scale-105 ${
                      achievement.completed
                        ? 'bg-gradient-to-br from-green-50 to-teal-50 border-green-200 shadow-lg'
                        : 'bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`p-2 rounded-xl ${
                        achievement.completed ? 'bg-green-100' : 'bg-gray-100'
                      }`}>
                        <Icon className={`w-5 h-5 ${
                          achievement.completed ? 'text-green-600' : 'text-gray-400'
                        }`} />
                      </div>
                      {achievement.completed && (
                        <Sparkles className="w-4 h-4 text-yellow-500" />
                      )}
                    </div>
                    <h4 className={`font-bold mb-1 ${
                      achievement.completed ? 'text-gray-900' : 'text-gray-500'
                    }`}>
                      {achievement.title}
                    </h4>
                    <p className={`text-sm ${
                      achievement.completed ? 'text-gray-700' : 'text-gray-400'
                    }`}>
                      {achievement.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Connected Devices */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-xl font-bold">
              <div className="p-2 bg-blue-100 rounded-xl">
                <Smartphone className="w-6 h-6 text-blue-600" />
              </div>
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Connected Devices
              </span>
            </CardTitle>
            <CardDescription>Manage your smart health devices</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {connectedDevices.map((device, index) => (
                <div key={index} className="flex items-center gap-4 p-4 border-2 border-gray-100 rounded-2xl hover:bg-gradient-to-r hover:from-gray-50 hover:to-blue-50 transition-all duration-300">
                  <div className="p-3 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl">
                    {device.type === 'Bluetooth' ? (
                      <Bluetooth className="w-6 h-6 text-blue-600" />
                    ) : (
                      <Wifi className="w-6 h-6 text-blue-600" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-900">{device.name}</h4>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">{device.type}</span>
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-green-600 font-medium">{device.status}</span>
                    </div>
                  </div>
                  {device.battery && (
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">{device.battery}%</div>
                      <div className="text-xs text-gray-500">Battery</div>
                    </div>
                  )}
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              ))}
              
              <Button variant="outline" className="w-full border-2 border-dashed border-gray-300 h-16 rounded-2xl hover:border-blue-300 hover:bg-blue-50 transition-all duration-300">
                <span className="text-gray-600">+ Add New Device</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-xl font-bold">
              <div className="p-2 bg-purple-100 rounded-xl">
                <Settings className="w-6 h-6 text-purple-600" />
              </div>
              <span className="bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
                Preferences
              </span>
            </CardTitle>
            <CardDescription>Customize your app experience</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Notifications */}
            <div className="space-y-4">
              <h4 className="font-bold text-gray-900 flex items-center gap-2">
                <Bell className="w-5 h-5 text-purple-600" />
                Notifications
              </h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl">
                  <div>
                    <Label className="font-medium text-gray-900">Push Notifications</Label>
                    <p className="text-sm text-gray-600">Receive alerts and updates</p>
                  </div>
                  <Switch 
                    checked={notificationsEnabled} 
                    onCheckedChange={setNotificationsEnabled}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-orange-50 rounded-2xl">
                  <div>
                    <Label className="font-medium text-gray-900">Air Quality Alerts</Label>
                    <p className="text-sm text-gray-600">Get notified about air quality changes</p>
                  </div>
                  <Switch 
                    checked={airQualityAlerts} 
                    onCheckedChange={setAirQualityAlerts}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-green-50 rounded-2xl">
                  <div>
                    <Label className="font-medium text-gray-900">Medication Reminders</Label>
                    <p className="text-sm text-gray-600">Daily inhaler usage reminders</p>
                  </div>
                  <Switch 
                    checked={medicationReminders} 
                    onCheckedChange={setMedicationReminders}
                  />
                </div>
              </div>
            </div>

            <Separator className="my-6" />

            {/* Privacy */}
            <div className="space-y-4">
              <h4 className="font-bold text-gray-900 flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-600" />
                Privacy & Data
              </h4>
              
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-purple-50 rounded-2xl">
                <div>
                  <Label className="font-medium text-gray-900">Data Sharing</Label>
                  <p className="text-sm text-gray-600">Share anonymous data for research</p>
                </div>
                <Switch 
                  checked={dataSharingEnabled} 
                  onCheckedChange={setDataSharingEnabled}
                />
              </div>
            </div>

            <Separator className="my-6" />

            {/* Account Management */}
            <div className="space-y-4">
              <h4 className="font-bold text-gray-900">Account</h4>
              
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 hover:border-blue-300 hover:bg-blue-50 transition-all duration-300">
                  <User className="w-5 h-5 mr-3 text-blue-600" />
                  <span className="flex-1 text-left">Personal Information</span>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </Button>
                
                <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 hover:border-purple-300 hover:bg-purple-50 transition-all duration-300">
                  <Calendar className="w-5 h-5 mr-3 text-purple-600" />
                  <span className="flex-1 text-left">Medication Schedule</span>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </Button>
                
                <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 hover:border-green-300 hover:bg-green-50 transition-all duration-300">
                  <Shield className="w-5 h-5 mr-3 text-green-600" />
                  <span className="flex-1 text-left">Privacy Settings</span>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support & About */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 hover:border-blue-300 hover:bg-blue-50 transition-all duration-300">
                <span className="flex-1 text-left">Help & Support</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </Button>
              
              <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 hover:border-purple-300 hover:bg-purple-50 transition-all duration-300">
                <span className="flex-1 text-left">About AI Smart Inhaler</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </Button>
              
              <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 hover:border-orange-300 hover:bg-orange-50 transition-all duration-300">
                <span className="flex-1 text-left">Terms & Privacy Policy</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Sign Out */}
        <Card className="shadow-xl border-0 bg-gradient-to-br from-red-50 to-pink-50 border-2 border-red-200">
          <CardContent className="p-6">
            <Button variant="outline" className="w-full justify-start h-14 rounded-2xl border-2 border-red-300 text-red-600 hover:bg-red-50 transition-all duration-300">
              <LogOut className="w-5 h-5 mr-3" />
              <span className="flex-1 text-left">Sign Out</span>
            </Button>
          </CardContent>
        </Card>

        {/* App Version */}
        <div className="text-center text-gray-500 text-sm">
          AI Smart Inhaler v2.1.0
        </div>
      </div>
    </div>
  );
}