import { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Play, 
  Pause, 
  StopCircle, 
  CheckCircle, 
  XCircle, 
  Wind,
  Timer,
  Activity,
  Sparkles
} from 'lucide-react';

export function SessionScreen() {
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [currentBreathPhase, setCurrentBreathPhase] = useState<'inhale' | 'hold' | 'exhale' | 'ready'>('ready');
  const [breathingAnimation, setBreathingAnimation] = useState(0);
  const [sessionData, setSessionData] = useState({
    totalBreaths: 0,
    correctTechnique: 0,
    flowRate: 0,
    duration: 0,
    feedback: 'Ready to start'
  });

  // Simulate session timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSessionActive) {
      interval = setInterval(() => {
        setSessionTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isSessionActive]);

  // Simulate breathing animation and sensor data
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSessionActive) {
      interval = setInterval(() => {
        // Simulate breathing cycle: inhale (4s) -> hold (2s) -> exhale (4s)
        const cycleTime = (sessionTime % 10);
        
        if (cycleTime < 4) {
          setCurrentBreathPhase('inhale');
          setBreathingAnimation((cycleTime / 4) * 100);
          setSessionData(prev => ({
            ...prev,
            flowRate: 45 + Math.random() * 10,
            feedback: 'Inhale slowly and deeply'
          }));
        } else if (cycleTime < 6) {
          setCurrentBreathPhase('hold');
          setBreathingAnimation(100);
          setSessionData(prev => ({
            ...prev,
            flowRate: 0,
            feedback: 'Hold your breath'
          }));
        } else {
          setCurrentBreathPhase('exhale');
          setBreathingAnimation(100 - ((cycleTime - 6) / 4) * 100);
          setSessionData(prev => ({
            ...prev,
            flowRate: 35 + Math.random() * 8,
            feedback: 'Exhale completely'
          }));
          
          // Complete a breath cycle
          if (cycleTime >= 9.8) {
            setSessionData(prev => ({
              ...prev,
              totalBreaths: prev.totalBreaths + 1,
              correctTechnique: prev.correctTechnique + (Math.random() > 0.3 ? 1 : 0)
            }));
          }
        }
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isSessionActive, sessionTime]);

  const startSession = () => {
    setIsSessionActive(true);
    setSessionTime(0);
    setSessionData({
      totalBreaths: 0,
      correctTechnique: 0,
      flowRate: 0,
      duration: 0,
      feedback: 'Session started'
    });
  };

  const stopSession = () => {
    setIsSessionActive(false);
    setCurrentBreathPhase('ready');
    setBreathingAnimation(0);
    setSessionData(prev => ({
      ...prev,
      duration: sessionTime,
      feedback: 'Session completed'
    }));
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const techniqueAccuracy = sessionData.totalBreaths > 0 
    ? Math.round((sessionData.correctTechnique / sessionData.totalBreaths) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-600 text-white p-8 rounded-b-[2.5rem] shadow-xl shadow-purple-500/20 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 right-8 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-8 left-4 w-24 h-24 bg-cyan-300 rounded-full blur-2xl"></div>
        </div>

        <div className="flex items-center justify-between relative z-10">
          <div>
            <h1 className="text-3xl font-bold mb-1 drop-shadow-lg">Inhalation Session</h1>
            <p className="text-purple-100 drop-shadow-sm">Follow the breathing guide</p>
          </div>
          <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-2xl px-4 py-2 shadow-lg">
            <Timer className="w-6 h-6" />
            <span className="font-mono text-2xl font-bold">{formatTime(sessionTime)}</span>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Breathing Visualization */}
        <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-50/50 via-blue-50/50 to-cyan-50/50"></div>
          <CardContent className="p-8 relative z-10">
            <div className="text-center space-y-8">
              {/* Animated Circle */}
              <div className="relative flex items-center justify-center">
                <div className="absolute inset-0 flex items-center justify-center">
                  {/* Outer rings for enhanced visual effect */}
                  <div className={`w-64 h-64 rounded-full border-4 opacity-20 transition-all duration-1000 ${
                    currentBreathPhase === 'inhale' ? 'border-green-400' :
                    currentBreathPhase === 'hold' ? 'border-blue-400' :
                    currentBreathPhase === 'exhale' ? 'border-orange-400' :
                    'border-gray-300'
                  }`} style={{ transform: `scale(${0.8 + (breathingAnimation / 100) * 0.4})` }}></div>
                  
                  <div className={`w-56 h-56 rounded-full border-4 opacity-40 transition-all duration-1000 ${
                    currentBreathPhase === 'inhale' ? 'border-green-400' :
                    currentBreathPhase === 'hold' ? 'border-blue-400' :
                    currentBreathPhase === 'exhale' ? 'border-orange-400' :
                    'border-gray-300'
                  }`} style={{ transform: `scale(${0.9 + (breathingAnimation / 100) * 0.3})` }}></div>
                </div>

                <div 
                  className={`relative w-48 h-48 rounded-full border-8 transition-all duration-1000 shadow-2xl ${
                    currentBreathPhase === 'inhale' 
                      ? 'border-green-400 bg-gradient-to-br from-green-50 to-green-100 shadow-green-400/30' 
                      : currentBreathPhase === 'hold'
                      ? 'border-blue-400 bg-gradient-to-br from-blue-50 to-blue-100 shadow-blue-400/30'
                      : currentBreathPhase === 'exhale'
                      ? 'border-orange-400 bg-gradient-to-br from-orange-50 to-orange-100 shadow-orange-400/30'
                      : 'border-gray-300 bg-gradient-to-br from-gray-50 to-gray-100 shadow-gray-400/30'
                  }`}
                  style={{
                    transform: `scale(${0.7 + (breathingAnimation / 100) * 0.3})`,
                  }}
                >
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className={`p-4 rounded-full ${
                      currentBreathPhase === 'inhale' ? 'bg-green-500/20' :
                      currentBreathPhase === 'hold' ? 'bg-blue-500/20' :
                      currentBreathPhase === 'exhale' ? 'bg-orange-500/20' :
                      'bg-gray-500/20'
                    }`}>
                      <Wind className={`w-16 h-16 ${
                        currentBreathPhase === 'inhale' ? 'text-green-600' :
                        currentBreathPhase === 'hold' ? 'text-blue-600' :
                        currentBreathPhase === 'exhale' ? 'text-orange-600' :
                        'text-gray-400'
                      }`} />
                    </div>
                  </div>
                  
                  {/* Sparkle effect for excellent technique */}
                  {techniqueAccuracy > 80 && isSessionActive && (
                    <div className="absolute -top-2 -right-2">
                      <Sparkles className="w-8 h-8 text-yellow-500 animate-pulse" />
                    </div>
                  )}
                </div>
              </div>

              {/* Phase Indicator */}
              <div className="space-y-3">
                <Badge 
                  variant="secondary" 
                  className={`text-xl px-6 py-3 font-semibold ${
                    currentBreathPhase === 'inhale' ? 'bg-green-100 text-green-800 border-green-300' :
                    currentBreathPhase === 'hold' ? 'bg-blue-100 text-blue-800 border-blue-300' :
                    currentBreathPhase === 'exhale' ? 'bg-orange-100 text-orange-800 border-orange-300' :
                    'bg-gray-100 text-gray-800 border-gray-300'
                  }`}
                >
                  {currentBreathPhase === 'ready' ? 'Ready to Begin' : 
                   currentBreathPhase === 'inhale' ? 'Breathe In' :
                   currentBreathPhase === 'hold' ? 'Hold' : 'Breathe Out'}
                </Badge>
                <p className="text-gray-700 font-medium text-lg">{sessionData.feedback}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Live Sensor Data */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-purple-600 to-cyan-600 bg-clip-text text-transparent">Live Sensor Data</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-4 border border-blue-100">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <span className="text-sm text-gray-600 font-medium">Flow Rate</span>
                </div>
                <div className="text-3xl font-bold text-blue-600">{sessionData.flowRate.toFixed(1)}</div>
                <div className="text-sm text-gray-500 mb-2">L/min</div>
                <Progress value={Math.min(sessionData.flowRate, 100)} className="h-2 bg-blue-100" />
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-4 border border-green-100">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-gray-600 font-medium">Accuracy</span>
                </div>
                <div className="text-3xl font-bold text-green-600">{techniqueAccuracy}%</div>
                <div className="text-sm text-gray-500 mb-2">Current</div>
                <Progress value={techniqueAccuracy} className="h-2 bg-green-100" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Session Stats */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-purple-600 to-cyan-600 bg-clip-text text-transparent">Session Statistics</h3>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-4">
                <div className="text-3xl font-bold text-purple-600">{sessionData.totalBreaths}</div>
                <div className="text-sm text-gray-600 font-medium">Total Breaths</div>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-4">
                <div className="text-3xl font-bold text-green-600">{sessionData.correctTechnique}</div>
                <div className="text-sm text-gray-600 font-medium">Correct Technique</div>
              </div>
              
              <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-4">
                <div className="text-3xl font-bold text-orange-600">{formatTime(sessionTime)}</div>
                <div className="text-sm text-gray-600 font-medium">Duration</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Real-time Feedback */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-purple-600 to-cyan-600 bg-clip-text text-transparent">Real-time Feedback</h3>
            
            <div className="space-y-3">
              {sessionData.totalBreaths > 0 && (
                <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-green-50 to-teal-50 rounded-2xl border border-green-200">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  <span className="text-green-800 font-medium">Good breathing rhythm</span>
                </div>
              )}
              
              {sessionData.flowRate > 60 && isSessionActive && (
                <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-2xl border border-orange-200">
                  <XCircle className="w-6 h-6 text-orange-600" />
                  <span className="text-orange-800 font-medium">Try to inhale more slowly</span>
                </div>
              )}
              
              {!isSessionActive && sessionData.totalBreaths === 0 && (
                <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl border border-blue-200">
                  <Activity className="w-6 h-6 text-blue-600" />
                  <span className="text-blue-800 font-medium">Ready to start your session</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Control Buttons */}
        <div className="space-y-4">
          {!isSessionActive ? (
            <Button 
              onClick={startSession}
              size="lg" 
              className="w-full bg-gradient-to-r from-green-600 to-teal-500 hover:from-green-700 hover:to-teal-600 h-16 rounded-2xl text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-teal-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <Play className="w-6 h-6 mr-3 relative z-10" />
              <span className="relative z-10 font-semibold">Start Session</span>
            </Button>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <Button 
                onClick={() => setIsSessionActive(!isSessionActive)}
                variant="outline" 
                size="lg"
                className="h-16 rounded-2xl border-2 border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-all duration-300 hover:scale-105"
              >
                <Pause className="w-6 h-6 mr-2" />
                Pause
              </Button>
              
              <Button 
                onClick={stopSession}
                variant="destructive" 
                size="lg"
                className="h-16 rounded-2xl bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                <StopCircle className="w-6 h-6 mr-2" />
                Stop
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}