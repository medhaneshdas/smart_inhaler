import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Area,
  AreaChart
} from 'recharts';
import { 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  Wind, 
  Calendar,
  Lightbulb,
  Shield,
  Target,
  Sparkles,
  Star
} from 'lucide-react';

export function InsightsScreen() {
  const riskScore = 'Low';
  const riskPercentage = 25;
  
  // Mock data for trends
  const riskTrendData = [
    { date: '2024-08-19', risk: 35, accuracy: 78, airQuality: 45 },
    { date: '2024-08-20', risk: 32, accuracy: 82, airQuality: 38 },
    { date: '2024-08-21', risk: 28, accuracy: 85, airQuality: 42 },
    { date: '2024-08-22', risk: 30, accuracy: 80, airQuality: 55 },
    { date: '2024-08-23', risk: 25, accuracy: 89, airQuality: 35 },
    { date: '2024-08-24', risk: 22, accuracy: 91, airQuality: 32 },
    { date: '2024-08-25', risk: 25, accuracy: 87, airQuality: 40 }
  ];

  const insights = [
    {
      type: 'positive',
      icon: TrendingUp,
      title: 'Technique Improvement',
      description: 'Your inhaler technique has improved by 12% over the past week',
      color: 'text-green-600',
      bgColor: 'bg-gradient-to-br from-green-50 to-teal-50',
      borderColor: 'border-green-200'
    },
    {
      type: 'warning',
      icon: Wind,
      title: 'Air Quality Alert',
      description: 'Air quality will be poor tomorrow. Consider staying indoors during peak hours',
      color: 'text-orange-600',
      bgColor: 'bg-gradient-to-br from-orange-50 to-red-50',
      borderColor: 'border-orange-200'
    },
    {
      type: 'recommendation',
      icon: Lightbulb,
      title: 'Timing Optimization',
      description: 'Your best performance is typically in the morning. Consider scheduling important activities then',
      color: 'text-blue-600',
      bgColor: 'bg-gradient-to-br from-blue-50 to-indigo-50',
      borderColor: 'border-blue-200'
    },
    {
      type: 'achievement',
      icon: Target,
      title: 'Weekly Goal Achieved',
      description: 'Congratulations! You maintained >80% accuracy for 7 consecutive days',
      color: 'text-purple-600',
      bgColor: 'bg-gradient-to-br from-purple-50 to-pink-50',
      borderColor: 'border-purple-200'
    }
  ];

  const healthTips = [
    {
      category: 'Technique',
      tip: 'Try practicing the "4-7-8" breathing technique: inhale for 4 seconds, hold for 7, exhale for 8',
      priority: 'high',
      icon: Target
    },
    {
      category: 'Environment',
      tip: 'Use your inhaler 15-20 minutes before going outside when air quality is poor',
      priority: 'medium',
      icon: Wind
    },
    {
      category: 'Timing',
      tip: 'Your medication works best when taken consistently at the same times each day',
      priority: 'high',
      icon: Calendar
    },
    {
      category: 'Lifestyle',
      tip: 'Regular light exercise can improve your lung capacity and inhaler effectiveness',
      priority: 'low',
      icon: TrendingUp
    }
  ];

  const getRiskColor = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'low': return { text: 'text-green-600', bg: 'bg-gradient-to-br from-green-100 to-teal-100', border: 'border-green-200' };
      case 'medium': return { text: 'text-yellow-600', bg: 'bg-gradient-to-br from-yellow-100 to-orange-100', border: 'border-yellow-200' };
      case 'high': return { text: 'text-red-600', bg: 'bg-gradient-to-br from-red-100 to-pink-100', border: 'border-red-200' };
      default: return { text: 'text-gray-600', bg: 'bg-gradient-to-br from-gray-100 to-gray-200', border: 'border-gray-200' };
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-red-200 text-red-700 bg-red-50';
      case 'medium': return 'border-yellow-200 text-yellow-700 bg-yellow-50';
      case 'low': return 'border-green-200 text-green-700 bg-green-50';
      default: return 'border-gray-200 text-gray-700 bg-gray-50';
    }
  };

  const riskColors = getRiskColor(riskScore);

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-600 text-white p-8 rounded-b-[2.5rem] shadow-xl shadow-violet-500/20 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 right-8 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-8 left-4 w-24 h-24 bg-indigo-300 rounded-full blur-2xl"></div>
        </div>

        <div className="flex items-center gap-4 mb-4 relative z-10">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg">
            <Brain className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-1 drop-shadow-lg">AI Health Insights</h1>
            <p className="text-violet-100 drop-shadow-sm">Personalized health intelligence powered by AI</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Risk Score Card */}
        <Card className={`shadow-2xl border-2 ${riskColors.border} ${riskColors.bg} overflow-hidden relative`}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 rounded-full blur-2xl"></div>
          <CardHeader className="pb-3 relative z-10">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3 text-xl font-bold">
                <div className="p-2 bg-white/80 rounded-xl shadow-lg">
                  <Shield className={`w-6 h-6 ${riskColors.text}`} />
                </div>
                <span className={riskColors.text}>Today's Risk Assessment</span>
              </CardTitle>
              <Badge className={`${riskColors.bg} ${riskColors.text} border-0 font-semibold px-3 py-1 shadow-lg`}>
                {riskScore} Risk
              </Badge>
            </div>
            <CardDescription className="text-gray-700">AI-powered analysis of your asthma risk factors</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="space-y-6">
              <div className="text-center">
                <div className="relative inline-block">
                  <div className={`text-6xl font-bold ${riskColors.text} mb-2`}>
                    {riskPercentage}%
                  </div>
                  <Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-yellow-500" />
                </div>
                <p className="text-gray-700 font-medium">
                  Your risk is currently {riskScore.toLowerCase()}. Keep up the excellent work!
                </p>
              </div>
              
              <Progress 
                value={riskPercentage} 
                className="h-4 bg-white/50"
              />
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-white/60 rounded-2xl p-4">
                  <div className="text-2xl font-bold text-green-600 mb-1">87%</div>
                  <div className="text-sm text-gray-600 font-medium">Technique</div>
                </div>
                <div className="bg-white/60 rounded-2xl p-4">
                  <div className="text-2xl font-bold text-blue-600 mb-1">Good</div>
                  <div className="text-sm text-gray-600 font-medium">Air Quality</div>
                </div>
                <div className="bg-white/60 rounded-2xl p-4">
                  <div className="text-2xl font-bold text-purple-600 mb-1">Stable</div>
                  <div className="text-sm text-gray-600 font-medium">Trends</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Trend Chart */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm overflow-hidden relative">
          <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-green-400/10 to-blue-400/10 rounded-full blur-2xl"></div>
          <CardHeader className="relative z-10">
            <CardTitle className="flex items-center gap-3 text-xl font-bold">
              <div className="p-2 bg-green-100 rounded-xl">
                <TrendingDown className="w-6 h-6 text-green-600" />
              </div>
              <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                Risk vs. Accuracy Trend
              </span>
            </CardTitle>
            <CardDescription>Correlation between your technique and risk factors</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={riskTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="date" 
                    fontSize={12}
                    stroke="#6b7280"
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis fontSize={12} stroke="#6b7280" />
                  <Tooltip 
                    formatter={(value, name) => [
                      name === 'risk' ? `${value}%` : name === 'accuracy' ? `${value}%` : value,
                      name === 'risk' ? 'Risk Score' : name === 'accuracy' ? 'Technique Accuracy' : 'Air Quality Index'
                    ]}
                    labelFormatter={(label) => new Date(label).toLocaleDateString()}
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      border: 'none',
                      borderRadius: '12px',
                      boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="risk" 
                    stackId="1"
                    stroke="#ef4444" 
                    fill="url(#riskGradient)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="accuracy" 
                    stackId="2"
                    stroke="#10b981" 
                    fill="url(#accuracyGradient)"
                  />
                  <defs>
                    <linearGradient id="riskGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#ef4444" stopOpacity={0.1} />
                    </linearGradient>
                    <linearGradient id="accuracyGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* AI Insights */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-xl font-bold">
              <div className="p-2 bg-purple-100 rounded-xl">
                <Brain className="w-6 h-6 text-purple-600" />
              </div>
              <span className="bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
                Smart Insights
              </span>
            </CardTitle>
            <CardDescription>AI-generated insights based on your data patterns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {insights.map((insight, index) => {
                const Icon = insight.icon;
                return (
                  <div 
                    key={index}
                    className={`p-5 rounded-2xl border-2 ${insight.bgColor} ${insight.borderColor} hover:scale-[1.02] transition-transform duration-300 shadow-lg`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-2xl bg-white shadow-lg ${insight.color}`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900 mb-2 text-lg">{insight.title}</h4>
                        <p className="text-gray-700 leading-relaxed">{insight.description}</p>
                      </div>
                      {insight.type === 'achievement' && (
                        <Star className="w-6 h-6 text-yellow-500" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Personalized Health Tips */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-xl font-bold">
              <div className="p-2 bg-yellow-100 rounded-xl">
                <Lightbulb className="w-6 h-6 text-yellow-600" />
              </div>
              <span className="bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
                Personalized Tips
              </span>
            </CardTitle>
            <CardDescription>Tailored recommendations for better asthma management</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {healthTips.map((tip, index) => {
                const Icon = tip.icon;
                return (
                  <div key={index} className="flex items-start gap-4 p-4 border-2 border-gray-100 rounded-2xl hover:bg-gradient-to-r hover:from-gray-50 hover:to-blue-50 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
                    <div className="flex-shrink-0 p-2 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                      <Icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-bold text-gray-900">{tip.category}</span>
                        <Badge 
                          variant="outline" 
                          className={`text-xs font-medium ${getPriorityColor(tip.priority)}`}
                        >
                          {tip.priority} priority
                        </Badge>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{tip.tip}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Weekly Summary */}
        <Card className="shadow-xl border-0 bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400/20 to-teal-400/20 rounded-full blur-2xl"></div>
          <CardContent className="p-6 relative z-10">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-teal-500 rounded-2xl flex items-center justify-center shadow-lg">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Weekly Achievement</h3>
                <p className="text-gray-700">Outstanding progress this week!</p>
              </div>
              <Sparkles className="w-8 h-8 text-yellow-500 ml-auto" />
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-white/60 rounded-2xl p-4">
                <div className="text-3xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">
                  +12%
                </div>
                <div className="text-sm text-gray-600 font-medium">Accuracy Improvement</div>
              </div>
              <div className="bg-white/60 rounded-2xl p-4">
                <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  7/7
                </div>
                <div className="text-sm text-gray-600 font-medium">Goal Days Met</div>
              </div>
              <div className="bg-white/60 rounded-2xl p-4">
                <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  23
                </div>
                <div className="text-sm text-gray-600 font-medium">Total Sessions</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}